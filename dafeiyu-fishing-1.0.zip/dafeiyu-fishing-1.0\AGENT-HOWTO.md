# 给 agent 的试玩手册（v1.0）

> 目标读者：拿到这个包的 agent。你要做的是——部署、玩一局、把分数和截图报回去。
> 所有命令都在包目录内执行，路径相对，不依赖作者机器。

---

## 1. 部署

1. 把压缩包解压到任意**纯英文路径**（例如 `D:\games\dafeiyu-fishing`），别放中文/空格路径（Windows PowerShell 5.1 对编码很敏感）。
2. 确认目录里有 `index.html` 和 `play.ps1`。
3. 可选自检：`powershell -NoProfile -ExecutionPolicy Bypass -File .\verify.ps1` → 输出 `ALL OK`。

不需要安装任何依赖，不需要联网。

---

## 2. 一分钟版

```powershell
cd <包目录>
powershell -NoProfile -ExecutionPolicy Bypass -File .\play.ps1 -Headless -FreshProfile
```

约 65 秒后输出一行 JSON：

```json
{"ok":true,"score":938,"state":"over","afei":938,"song":0,"plays":1,"combo":1,"screenshot":"...\\play-end.png","game_sha256":"...","url":"file:///..."}
```

- `ok:true` + `state:"over"` = 跑完一局
- `score` = 本局得分（记录在浏览器本地，不联网、不上传）
- `screenshot` = 结算面板 PNG
- `game_sha256` = 本次运行的游戏文件指纹，应与 `SHA256SUMS.txt` 里 `index.html` 一致

---

## 3. URL 参数

| 参数 | 作用 |
|---|---|
| `auto=1` | 标题页停 1 秒后自动开局（agent 必带） |
| `who=afei` | 成绩记到「阿肥」名下（默认记「松松」） |
| `demo=1` | 交给游戏内置 AI 打，不是 agent 操控 |
| `speed=1.6` | 游戏内时间倍速，仅用于快速验证 |
| `debug=1` | 左下角显示内部状态 |
| `round=30` | 单局秒数，默认 60 |

`play.ps1 -Url` 只接受 `file:///` 或 `http://127.0.0.1|localhost` 开头的地址，其它会被拒绝（安全设计，见 README）。

---

## 4. 规则数值（写策略用）

| 项目 | 数值 |
|---|---|
| 接鱼判定 | \|x−玩家x\| < 58，y ∈ [玩家y−36, 玩家y+52]（玩家 y=520） |
| 水母判定 | \|x−玩家x\| < 44；撞到：晕 1.15s、扣 15 分、连击清零 |
| 鲸吸 | 冷却 6.2s，持续 0.55s，半径涨到 220；只吸鱼不吸水母 |
| 连击倍率 | 1 + floor(combo/5)×0.5，上限 ×4 |
| 断连击 | 撞水母，或**任何一条鱼漏到屏幕下方** |
| 刷怪 | 0.82s → 0.52s 递减，60 秒约 90 条 |
| 分值 | 沙丁 10 / 河豚 15 / 小丑 20 / 章鱼 30 / 珍珠 50 |
| 评级 | 500 学徒 / 1000 渔娘 / 1600 鲸落女王 / 2400 深海传说 |

**关键：漏一条鱼就断连击。** 所以站到「鱼最密的那一列」比追单条贵鱼更划算。

---

## 5. 状态接口（只读）

```js
window.__dafeiyu.snapshot()
// { state:"title|playing|over", mode:"solo|demo", score, timeLeft, combo,
//   best:{afei,song,plays}, player:{x,y,stun}, skill:{cd,active},
//   fish:[{x,y,vx,vy,v,h,r}] }      // v=分值, h=是否水母, r=半径
window.__dafeiyu.start("solo")       // 开始一局
window.__dafeiyu.reset()             // 清零本机记录
```

接口只读，不能改分数。**不要**用 `Runtime.evaluate` 去改 `localStorage` 或内部变量——分数就不可信了。

读状态（CDP）：

```
Runtime.evaluate { expression: "JSON.stringify(window.__dafeiyu.snapshot())",
                   returnByValue: true }
```

---

## 6. 按键（CDP，不需要窗口在前台）

```
ArrowLeft  {type:"rawKeyDown", key:"ArrowLeft",  code:"ArrowLeft",  windowsVirtualKeyCode:37}
ArrowRight {type:"rawKeyDown", key:"ArrowRight", code:"ArrowRight", windowsVirtualKeyCode:39}
Space      {type:"rawKeyDown", key:" ",          code:"Space",      windowsVirtualKeyCode:32}
松开       {type:"keyUp", ... 同字段}
```

- **按住**：发一次 `rawKeyDown` 就会一直移动，直到 `keyUp`。不用连发。
- **空格**：`rawKeyDown` + `keyUp` 各一次，冷却由游戏自己算。
- 无头模式（`--headless=new`）完全可用。

---

## 7. 策略：12 车道蹲守（实测最优）

```
分 12 列（x = 66 + i*74）
for 每条鱼:
    eta   = (玩家y − 鱼y) / max(45, 鱼vy)
    predX = 鱼x + 鱼vx * max(0, eta)
    col   = round((predX − 66) / 74)
    if 水母: eta < 1.6s → 该列 −900；eta < 1.4s 且 |predX−玩家x| < 120 → 记危险
    else:    该列 += 分值 * (1 + 0.6*exp(−max(0,eta)/3))

站到分最高的列中心（夹在 66..894）
若有危险：往水母反方向让 210px（最高优先级）
若上方 340px 内 ≥3 条鱼在 ±170 内且鲸吸冷却为 0：按空格
```

同脚本三种打法实测：追单条 425 / 追+落点预测 590 / 车道蹲守 **938**。

---

## 8. 坑

1. **分数按「浏览器配置 + origin」隔离**：`file://` 与 `http://127.0.0.1:8777` 是两套 localStorage，别指望互相看到。
2. `-FreshProfile` 会清空历史记录；想保留就把 JSON 里的 `afei` 抄下来。
3. 别用同一个 `-Profile` 并发跑两个实例（端口会连到旧页面）；换 `-Port` 或加 `-FreshProfile`。
4. 中文/空格路径可能让 PowerShell 5.1 出怪问题，包放纯英文路径。
5. 没有鼠标操作，只有键盘；给人类才用点击「开始捞鱼」。
6. 别用加速局（`speed`）的分数跟正常局比。
7. 别试图用脚本改分：这份记录是要拿去跟人对账的。

---

## 9. 交付前自检

- [ ] `verify.ps1` 输出 `ALL OK`
- [ ] `play.ps1` 输出 `"ok":true` 且 `state:"over"`
- [ ] `score > 0`，`screenshot` 能打开且是结算面板
- [ ] `game_sha256` 与 `SHA256SUMS.txt` 中 `index.html` 一致
- [ ] 没有手动改 `localStorage` / 内部变量
- [ ] 把分数、截图路径、`game_sha256` 一起报回去

---

## 10. 安全

本包不联网、不装服务、不写注册表、不读包外文件；调试端口只绑 `127.0.0.1`；`play.ps1` 拒绝远程 URL。详见 `README.md` 的「安全边界」。
