param(
  [int]$Port = 9344,
  [string]$Profile = "",
  [string]$Url = "",
  [double]$MaxSeconds = 90,
  [string]$Shot = "",
  [switch]$Headless,
  [switch]$FreshProfile
)
# ---------------------------------------------------------------------------
#  play.ps1 - let an agent (or a human) play ONE round of the fishing game.
#
#  Safety properties of this script:
#   * it does NOT use the network: the page is file:// and the only socket is
#     the browser's own DevTools port, bound to 127.0.0.1 (loopback only);
#   * it refuses any URL that is not file:/// or http://127.0.0.1 / localhost;
#   * it refuses a -Profile path outside this package folder;
#   * it never writes outside the package folder (except -Shot, a .png path);
#   * it never installs a service, scheduled task, registry key or autorun;
#   * it only kills browser processes that were started with THIS profile.
#
#  ASCII-only on purpose: Windows PowerShell 5.1 decodes UTF-8-no-BOM as GBK.
# ---------------------------------------------------------------------------
$ErrorActionPreference = "Stop"

$Root = $PSScriptRoot
if (-not $Root) { $Root = (Get-Location).Path }
$Root = [System.IO.Path]::GetFullPath($Root)
$game = Join-Path $Root "index.html"
if (-not (Test-Path -LiteralPath $game)) {
  Write-Output '{"ok":false,"error":"index.html_missing"}'
  exit 2
}

if ($Profile -eq "") { $Profile = Join-Path $Root ".edge-play" }
$profFull = [System.IO.Path]::GetFullPath($Profile)
if (-not $profFull.StartsWith($Root, [System.StringComparison]::OrdinalIgnoreCase)) {
  Write-Output '{"ok":false,"error":"profile_must_be_inside_package"}'
  exit 2
}
$Profile = $profFull
if ($FreshProfile) {
  $Profile = Join-Path $Root (".edge-play-" + [guid]::NewGuid().ToString("N").Substring(0, 8))
}

if ($Shot -eq "") { $Shot = Join-Path $Root "play-end.png" }
if ($Shot -notmatch '\.png$') {
  Write-Output '{"ok":false,"error":"shot_must_be_png"}'
  exit 2
}
$shotDir = Split-Path -Parent $Shot
if ($shotDir -and -not (Test-Path -LiteralPath $shotDir)) {
  New-Item -ItemType Directory -Force -Path $shotDir | Out-Null
}

# find a Chromium browser
$edge = ""
foreach ($c in @(
    "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "C:\Program Files\Google\Chrome\Application\chrome.exe",
    "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
  )) {
  if (Test-Path -LiteralPath $c) { $edge = $c; break }
}
if ($edge -eq "") {
  Write-Output '{"ok":false,"error":"no_edge_or_chrome_found"}'
  exit 2
}

if ($Url -eq "") {
  $fileUrl = "file:///" + ($game -replace '\\', '/')
  $Url = $fileUrl + "?auto=1&who=afei&v=" + (Get-Date -Format "HHmmss")
}
if (-not ($Url -match '^file:///' -or $Url -match '^http://(127\.0\.0\.1|localhost)(:\d+)?/')) {
  Write-Output '{"ok":false,"error":"url_must_be_local"}'
  exit 2
}

# stop leftovers that were launched with THIS profile only
Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like "*$Profile*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

$eargs = @(
  "--user-data-dir=$Profile",
  "--remote-debugging-port=$Port",
  "--remote-debugging-address=127.0.0.1",
  "--no-first-run", "--no-default-browser-check", "--disable-extensions",
  "--disable-sync", "--no-pings", "--metrics-recording-only",
  "--window-size=1280,800"
)
if ($Headless) { $eargs += "--headless=new" }
$eargs += $Url
Start-Process -FilePath $edge -ArgumentList $eargs

# wait for the page target (loopback only)
$page = $null
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Milliseconds 250
  try { $list = Invoke-RestMethod "http://127.0.0.1:$Port/json/list" -TimeoutSec 2 } catch { continue }
  $page = $list | Where-Object { $_.type -eq "page" -and $_.url -like "*game_test*" } | Select-Object -First 1
  if (-not $page) { $page = $list | Where-Object { $_.type -eq "page" } | Select-Object -First 1 }
  if ($page) { break }
}
if (-not $page) {
  Write-Output '{"ok":false,"error":"no_page_target"}'
  exit 2
}

$ws = [System.Net.WebSockets.ClientWebSocket]::new()
$ws.ConnectAsync([Uri]$page.webSocketDebuggerUrl, [System.Threading.CancellationToken]::None).Wait() | Out-Null
$buf = New-Object byte[] 1048576
$seg = [System.ArraySegment[byte]]::new($buf)
$script:cid = 0

function Send-Cdp([int]$id, [string]$method, $params) {
  $msg = @{ id = $id; method = $method; params = $params } | ConvertTo-Json -Depth 8 -Compress
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($msg)
  $s = [System.ArraySegment[byte]]::new($bytes)
  $ws.SendAsync($s, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [System.Threading.CancellationToken]::None).Wait() | Out-Null
}

function Recv-Cdp([int]$id) {
  $sb = New-Object System.Text.StringBuilder
  for ($i = 0; $i -lt 200; $i++) {
    $r = $ws.ReceiveAsync($seg, [System.Threading.CancellationToken]::None).Result
    [void]$sb.Append([System.Text.Encoding]::UTF8.GetString($buf, 0, $r.Count))
    if (-not $r.EndOfMessage) { continue }
    $txt = $sb.ToString(); [void]$sb.Clear()
    if ($txt -notmatch '"id"') { continue }
    $obj = $txt | ConvertFrom-Json
    if ($obj.id -eq $id) { return $obj }
  }
  return $null
}

function Eval-Js([string]$js) {
  $script:cid++
  Send-Cdp $script:cid "Runtime.evaluate" @{ expression = $js; returnByValue = $true }
  $r = Recv-Cdp $script:cid
  if ($r -and $r.result -and $r.result.result) { return $r.result.result.value }
  return $null
}

function Send-Key([string]$key, [string]$code, [int]$vk, [string]$type) {
  $script:cid++
  Send-Cdp $script:cid "Input.dispatchKeyEvent" @{
    type = $type; key = $key; code = $code
    windowsVirtualKeyCode = $vk; nativeVirtualKeyCode = $vk
  }
  Recv-Cdp $script:cid | Out-Null
}

Send-Cdp 1 "Page.enable" @{} | Out-Null
Recv-Cdp 1 | Out-Null

$snap = $null
$deadline = (Get-Date).AddSeconds(20)
while ((Get-Date) -lt $deadline) {
  $j = Eval-Js "window.__dafeiyu ? JSON.stringify(window.__dafeiyu.snapshot()) : null"
  if ($j) { $snap = $j | ConvertFrom-Json; if ($snap.state -eq "playing" -or $snap.state -eq "over") { break } }
  Start-Sleep -Milliseconds 150
}
if (-not $snap) {
  Write-Output '{"ok":false,"error":"no_game_api"}'
  exit 3
}

$heldLeft = $false
$heldRight = $false
$skillAt = Get-Date
$loopStart = Get-Date

while ($true) {
  $j = Eval-Js "JSON.stringify(window.__dafeiyu.snapshot())"
  if (-not $j) { Start-Sleep -Milliseconds 60; continue }
  $s = $j | ConvertFrom-Json
  if ($s.state -eq "over") { break }
  if (((Get-Date) - $loopStart).TotalSeconds -gt $MaxSeconds) { break }

  # lane strategy: stand under the densest descending column (keeps combos alive)
  $px = [double]$s.player.x
  $py = [double]$s.player.y
  $laneCount = 12
  $laneW = 74
  $laneX = @()
  $laneScore = @()
  for ($i = 0; $i -lt $laneCount; $i++) {
    $laneX += 66 + $i * $laneW
    $laneScore += 0.0
  }
  $danger = $null
  foreach ($f in $s.fish) {
    $vy = [math]::Max(45, [double]$f.vy)
    $eta = ($py - $f.y) / $vy
    $predX = [double]$f.x + [double]$f.vx * [math]::Max(0, $eta)
    if ($eta -lt -0.2) { continue }
    $li = [int][math]::Round(($predX - 66) / $laneW)
    if ($li -lt 0) { $li = 0 }
    if ($li -ge $laneCount) { $li = $laneCount - 1 }
    if ($f.h) {
      if ($eta -lt 1.6) { $laneScore[$li] -= 900 }
      if ($eta -gt -0.1 -and $eta -lt 1.4 -and [math]::Abs($predX - $px) -lt 120) {
        if (-not $danger -or $eta -lt $danger.eta) { $danger = @{ x = $predX; eta = $eta } }
      }
      continue
    }
    if ($eta -gt 6) { continue }
    $laneScore[$li] += [double]$f.v * (1.0 + 0.6 * [math]::Exp(-[math]::Max(0, $eta) / 3.0))
  }
  $bestLane = 0
  for ($i = 1; $i -lt $laneCount; $i++) { if ($laneScore[$i] -gt $laneScore[$bestLane]) { $bestLane = $i } }
  $targetX = $laneX[$bestLane]
  if ($danger) {
    $away = if ($px -lt $danger.x) { 210 } else { -210 }
    $targetX = $px + $away
  }
  $targetX = [math]::Max(66, [math]::Min(894, $targetX))

  $wantLeft = ($targetX -lt ($px - 10))
  $wantRight = ($targetX -gt ($px + 10))
  if ($wantLeft -and -not $heldLeft) { Send-Key "ArrowLeft" "ArrowLeft" 37 "rawKeyDown"; $heldLeft = $true }
  if (-not $wantLeft -and $heldLeft) { Send-Key "ArrowLeft" "ArrowLeft" 37 "keyUp"; $heldLeft = $false }
  if ($wantRight -and -not $heldRight) { Send-Key "ArrowRight" "ArrowRight" 39 "rawKeyDown"; $heldRight = $true }
  if (-not $wantRight -and $heldRight) { Send-Key "ArrowRight" "ArrowRight" 39 "keyUp"; $heldRight = $false }

  $nearFish = 0
  foreach ($f in $s.fish) {
    if ($f.h) { continue }
    if ($f.y -lt ($py - 45) -and $f.y -gt ($py - 340) -and [math]::Abs($f.x - $px) -lt 170) { $nearFish++ }
  }
  if ($nearFish -ge 3 -and $s.skill.cd -le 0 -and ((Get-Date) - $skillAt).TotalSeconds -gt 0.3) {
    Send-Key " " "Space" 32 "rawKeyDown"
    Send-Key " " "Space" 32 "keyUp"
    $skillAt = Get-Date
  }

  Start-Sleep -Milliseconds 45
}

if ($heldLeft) { Send-Key "ArrowLeft" "ArrowLeft" 37 "keyUp" }
if ($heldRight) { Send-Key "ArrowRight" "ArrowRight" 39 "keyUp" }

Start-Sleep -Milliseconds 400
$final = (Eval-Js "JSON.stringify(window.__dafeiyu.snapshot())") | ConvertFrom-Json

$shotOk = $false
try {
  $script:cid++
  Send-Cdp $script:cid "Page.captureScreenshot" @{ format = "png"; captureBeyondViewport = $false }
  $sr = Recv-Cdp $script:cid
  if ($sr -and $sr.result -and $sr.result.data) {
    [System.IO.File]::WriteAllBytes($Shot, [Convert]::FromBase64String($sr.result.data))
    $shotOk = $true
  }
} catch { }

try {
  $ws.CloseAsync([System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure, "done", [System.Threading.CancellationToken]::None).Wait() | Out-Null
} catch { }

$gameHash = (Get-FileHash -LiteralPath $game -Algorithm SHA256).Hash.ToLower()

$out = [ordered]@{
  ok = $true
  score = $final.score
  state = $final.state
  afei = $final.best.afei
  song = $final.best.song
  plays = $final.best.plays
  combo = $final.combo
  screenshot = $(if ($shotOk) { $Shot } else { "" })
  game_sha256 = $gameHash
  url = $Url
}
$out | ConvertTo-Json -Compress

Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -like "*$Profile*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
