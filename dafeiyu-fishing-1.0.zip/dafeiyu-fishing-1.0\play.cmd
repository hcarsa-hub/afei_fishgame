@echo off
REM Double-click this to play one round (headless browser, ~65 seconds).
REM It only touches the folder it sits in, and only talks to 127.0.0.1.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0play.ps1" -Headless -FreshProfile
echo.
pause
