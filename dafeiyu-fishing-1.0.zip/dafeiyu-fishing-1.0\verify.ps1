param([string]$Root = "")
# ---------------------------------------------------------------------------
#  verify.ps1 - check that every file still matches SHA256SUMS.txt
#  ASCII only. Exit code 0 = all good, 1 = mismatch, 2 = manifest missing.
# ---------------------------------------------------------------------------
if ($Root -eq "") { $Root = $PSScriptRoot }
if (-not $Root) { $Root = (Get-Location).Path }
$sum = Join-Path $Root "SHA256SUMS.txt"
if (-not (Test-Path -LiteralPath $sum)) {
  Write-Output "MISSING SHA256SUMS.txt"
  exit 2
}

$bad = 0
foreach ($line in (Get-Content -LiteralPath $sum -Encoding UTF8)) {
  $t = $line.Trim()
  if ($t -eq "" -or $t.StartsWith("#")) { continue }
  $parts = $t -split "\s+", 2
  if ($parts.Count -lt 2) { continue }
  $hash = $parts[0].ToLower()
  $name = $parts[1].TrimStart("*")
  $p = Join-Path $Root $name
  if (-not (Test-Path -LiteralPath $p)) {
    Write-Output ("MISSING " + $name)
    $bad++
    continue
  }
  $h = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower()
  if ($h -eq $hash) {
    Write-Output ("OK   " + $name)
  } else {
    Write-Output ("FAIL " + $name)
    $bad++
  }
}

if ($bad -gt 0) {
  Write-Output ("FAILED: " + $bad + " file(s)")
  exit 1
}
Write-Output "ALL OK"
