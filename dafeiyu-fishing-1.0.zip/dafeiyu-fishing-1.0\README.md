# 小肥鱼捞鱼记 · 深夜食堂 — 单文件小游戏（v1.0）

一个 60 秒一局的 HTML5 捞鱼小游戏。单文件、零依赖、不联网。
拿它的人可以自己解压、自己玩，也可以让 agent 用脚本自动试玩。

- 版本：v1.0（2026-10-22）
- 包大小：< 100 KB（游戏本体约 64 KB）
- 运行环境：Windows + 任意 Chromium 浏览器（Edge / Chrome）；游戏本体跨平台（任何现代浏览器双击 `index.html` 即可）

---

## 快速开始

**人玩**：双击 `index.html`，点「开始捞鱼」。← → 或 A/D 移动，空格鲸吸，别撞水母。

**让 agent 玩一局**：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\play.ps1 -Headless -FreshProfile
```

约 65 秒后输出：

```json
{"ok":true,"score":938,"state":"over","afei":938,"song":0,"plays":1,"combo":1,"screenshot":"...\\play-end.png","game_sha256":"...","url":"file:///...?auto=1&who=afei&v=..."}
```

`score` 是这局得分；`screenshot` 是结算截图；`game_sha256` 是本次运行的游戏文件指纹，可对照 `SHA256SUMS.txt` 确认没被改过。

细节手册（判定数值、状态接口、CDP 按键、策略伪代码、坑）：见 [AGENT-HOWTO.md](AGENT-HOWTO.md)。

---

## 安全边界（分享时请照抄给对方）

这个包**只做三件事**：渲染一个本地页面、开一个只绑回环地址的浏览器调试端口、在包目录里写截图。

- ❌ 不发起任何网络请求：页面是 `file://`，没有 fetch / XHR / WebSocket / img src / 外链脚本 / 统计埋点。
- ❌ 不安装任何东西：不写注册表、不装服务、不建计划任务、不设开机自启、不改系统设置。
- ❌ 不读包外的文件：除了浏览器自己的配置目录（就在包内 `.edge-play*`），不访问任何个人文件。
- ❌ 不接受远程地址：`play.ps1 -Url` 只放行 `file:///` 和 `http://127.0.0.1|localhost`，其它一律拒绝，避免被当成跳板。
- ❌ 不做远程执行：`Runtime.evaluate` 只执行脚本里写死的两条读取语句，不 eval 任何外部输入。
- ❌ 调试端口只绑 `127.0.0.1`（`--remote-debugging-address=127.0.0.1`），局域网和公网都连不上。
- ✅ 只能结束**用本包 profile 启动的**浏览器进程，不会误杀你正在用的浏览器。

**因此，拿到这个包的人无法通过它访问打包者的机器、账号或文件。**

### 拿到包后请自己验一遍（三步，不用信任任何人）

```powershell
# 1) 校验文件完整性
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify.ps1

# 2) 确认没有网络调用（应无输出）
Select-String -Path .\index.html -Pattern 'fetch\s*\(|XMLHttpRequest|new WebSocket|eval\s*\(|new Function|innerHTML|https?://'

# 3) 看清单
Get-Content .\SHA256SUMS.txt
```

`verify.ps1` 输出 `ALL OK` 才说明文件与发布时一致。

---

## 包内文件

| 文件 | 作用 |
|---|---|
| `index.html` | 游戏本体（单文件，含全部绘制与音效合成） |
| `play.ps1` | 让 agent 自动玩一局的驱动脚本（无头浏览器 + CDP） |
| `play.cmd` | 双击即可玩一局（等价于 `play.ps1 -Headless -FreshProfile`） |
| `verify.ps1` | 校验 `SHA256SUMS.txt` |
| `SHA256SUMS.txt` | 各文件 SHA-256 |
| `AGENT-HOWTO.md` | 给 agent 的完整操作手册 |
| `README.md` | 本文件 |
| `LICENSE.txt` | 许可与署名 |

运行后会多出 `.edge-play*`（浏览器临时配置）和 `play-end.png`（结算截图），都可以直接删。

---

## 许可

代码 MIT；画面全部由 canvas 绘制、音效由 WebAudio 合成，未打包任何第三方素材。
角色「小肥鱼阿肥/大肥鱼」为作者私有角色，仅限本包内使用。
